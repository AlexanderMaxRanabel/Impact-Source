---
title: Impact Changelog
canonical_url: https://impactclient.net/changelog
---

# Changelog
All notable changes to this project will be documented in this file.

The format is based on [Keep a Changelog](http://keepachangelog.com/en/1.0.0/) ~~and this project adheres to [Semantic Versioning](http://semver.org/spec/v2.0.0.html).~~

## Upcoming (already available to [donators](https://impactdevelopment.github.io/#donate))

## 4.9.1

### Added
- (1.13+) A File picker GUI to replace the broken Alt Import/Export dialogs
- Added "Active" setting to Breadcrumbs to disable position recording
- Added "breadcrumbs" command to save/load/clear breadcrumbs
- A `Randomize` module that randomly switches between hotbar slots

### Changed
- "Editions" watermarks such as "Impact Premium Edition" are now controlled by an API
- Changed the maximum Gamma in Light from 10 to 12
- Entities are now sorted in Shader ESP, closer ones will actually appear closer.
- Moved the `Impact Capes` controls from the `Customize Skin` GUI to a `Capes` module in the `Render` category, with added configurability.

### Fixed
- Fixed ClickGUI arrow key scrolling on 1.12.2
- Fixed `.set` not working on submodes of modules (e.g. now `.set elytra+ basespeed 6.338` does work)
- Fixed the "Created by" credits link not working on 1.13+
- Fixed Nametags disappearing when more than 230 blocks above the player (same source as issue 1235 applied to Nametags instead of Tracers)
- Fixed one tick of keyboard input leaking through to the player while in Freecam whenever a Baritone path ended
- Fixed Auto Walk interfering with Freecam ([#1679](https://github.com/ImpactDevelopment/ImpactIssues/issues/1679))
- Fixed HUD coords orientation not respecting Freecam setting
- Fixed Self Destruct not hiding the profile version in the debug screen
- Fixed Capes not displaying a full texture on 1.13+
- Fixed Fast Render disable not being applied on 1.13+
- Fixed Nametags, Tracers, and 2D ESP not rendering properly when the player's hand isn't visible.
- Fixed Freecam behavior in 1.14+ to match that of previous versions
- Fixed XRay compatibility with OptiFine on 1.13+
- Fixed first letter cutoff in ".plugins" command on 1.13+
- Fixed features managed by ".gui" not being saved
- Fixed Elytra+ Control mode being affected by the Speed potion effect
- Fixed render module compatibility with alternate view entities

## 4.8.3

### Added
- Added basic support for [TheAltening](https://thealtening.com) ([#1832](https://github.com/ImpactDevelopment/ImpactIssues/issues/1832))

### Fixed
 - Fixed Alt GUI background displaying incorrectly while in-game (1.14+ only)
 - Fixed Alt GUI's scrollbar (1.13+)
 - Fixed Alt GUI's preview player sometimes turning into steve or alex
 - Fixed .set command being unable to set some number values
 - TextLinks not being clickable when right-aligned

## 4.8.2

### Fixed
- Fixed ClickGUI bind going into search box ([#1732](https://github.com/ImpactDevelopment/ImpactIssues/issues/1732))
- Fixed keybinds activating at the same time as search characters ([#1745](https://github.com/ImpactDevelopment/ImpactIssues/issues/1745))
- Fixed Scaffold in 1.14.4 causing equip sound spam ([#1599](https://github.com/ImpactDevelopment/ImpactIssues/issues/1599))
- Updated Baritone to 1.4.3, fixing Search and various chat commands (1.14.4 only)
- Role colors not being parsed correctly if hex values

## 4.8.1

### Added
- Added 1.14.4 support
- Added a Positive option to Flight NCP which prevents void damage on some servers (with strange anticheats)
- Added a Skulls option to Auto Armor which prioritizes skull items (such as dragon heads 😉) over all other possible helmets
- Added a Reload Chunks option to Freecam which reloads rendered chunks on enable and disable
- Added a Search option to ClickGUI that highlights whatever modules match your typed query
- Added bite detection modes to AutoFish
- Added Biome HUD widget ([#1650](https://github.com/ImpactDevelopment/ImpactIssues/issues/1650))
- Added a Elytra option to Auto Armor which prioritizes Elytra over all other possible chestplates
- Added a Text Shadow to HUD which controls the pixel offset of the shadow of all text Impact draws
- Added many many new options to Tracers to precisely control the behavior, such as the tracer color change based on the distance to the target

### Changed
- Reordered Entities HUD widget to be the last one displayed
- Changed default position of ClickGUI panes to be left to right instead of stacked top to bottom

### Fixed
- Fixed Main Menu hide text not actually hiding all the text
- Fixed Freecam crashing while enabled on the main menu
- Fixed a projection crash on certain servers ([#1575](https://github.com/ImpactDevelopment/ImpactClient/issues/1575))
- Fixed a rare Baritone related crash on changing dimensions
- Fixed wobble in Search ([#1634](https://github.com/ImpactDevelopment/ImpactClient/issues/1634))
- Fixed a rare ESP2D crash ([#1677](https://github.com/ImpactDevelopment/ImpactClient/issues/1677))
- Fixed Tracers inverting at different Y coordinates ([#1235](https://github.com/ImpactDevelopment/ImpactClient/issues/1235))
- Fixed squid and dolphins not being targetable in 1.13+ ([#1689](https://github.com/ImpactDevelopment/ImpactIssues/issues/1689))
- Fixed premium check with OptiFine ([#1592](https://github.com/ImpactDevelopment/ImpactClient/issues/1592))
- Fixed StorageESP for Item Frames incorrectly rendering all in the same orientation
- Fixed issue where empty suffixes were still considered in HUD
- Fixed crash caused by saving malformed assets to disk ([#1652](https://github.com/ImpactDevelopment/ImpactClient/issues/1652))

## 4.7.3

### Fixed
- Fixed the bundled installer not properly updating to 1.14.4's OptiFine

## 4.7.2

### Fixed
- Fixed Flight mode NCP not enabling
- Fixed ESP Shader not soft failing on old OpenGL
- Fixed visual misalignment of the main menu

## 4.7.1

### Added
- Added new "Fill" option to Shader ESP with an opacity suboption
- Added text saying how to hide the Steal button on a chest
- Added commands to save and reload spam config from disk without having to restart ([#1243](https://github.com/ImpactDevelopment/ImpactClient/issues/1243))
- Added Yaw lock ([#417](https://github.com/ImpactDevelopment/ImpactClient/issues/417))
- Added more options for the Main Menu background, and an option to randomize the selection
- Added Nametags drawn on sound effects (aka Sound ESP)
- Added a height setting to Breadcrumbs to draw above blocks like snow or soul sand ([#1280](https://github.com/ImpactDevelopment/ImpactClient/issues/1280))
- Added a premium only feature to remove all the text from the top left of the main menu (GhOsT cLiEnT) ([#1297](https://github.com/ImpactDevelopment/ImpactClient/issues/1297))
- Added a way to specify different Tracer colors for Hostiles vs Passives ([#1293](https://github.com/ImpactDevelopment/ImpactClient/issues/1293))
- Added a new Flight mode for NCP
- Added commands `.preset save` and `.preset load` for all of Impact's settings ([#1298](https://github.com/ImpactDevelopment/ImpactClient/issues/1298))
- Added an option to HUD coords to show freecam position instead of player position ([#1184](https://github.com/ImpactDevelopment/ImpactClient/issues/1184))
- Added Anti Sound Lag ([#1295](https://github.com/ImpactDevelopment/ImpactClient/issues/1295))
- Added an option to disable typing the prefix opening the chat box (`.prefix openschat`) ([#1067](https://github.com/ImpactDevelopment/ImpactClient/issues/1067))
- Added the installer built into the client. Clicking the Install button will open the Impact installer, instead of the website. Patch releases can be installed as easy as a single button. ([#1229](https://github.com/ImpactDevelopment/ImpactClient/issues/1229))
- Added an option to ESP to include end crystals, boats, and armor stands ([#1294](https://github.com/ImpactDevelopment/ImpactClient/issues/1294))
- Added an Anti Weakness option to Crystal Aura which sets off crystals with a sword when the weakness effect is present
- Added an option to disable the Totem overlay in Anti Overlay ([#1388](https://github.com/ImpactDevelopment/ImpactClient/issues/1388))
- Added Nether Quartz Ore preset option to Auto Mine ([#1389](https://github.com/ImpactDevelopment/ImpactClient/issues/1389))
- Added an Auto Farm module under Player (just a wrapper for Baritone's FarmProcess)
- Added an option to disable the Elder Guardian effect in Anti Overlay ([#1388](https://github.com/ImpactDevelopment/ImpactClient/issues/1388))

### Changed
- Made module category and name changes described in [#1103](https://github.com/ImpactDevelopment/ImpactClient/issues/1103)
- Renamed "Rainbow Enchant" to "Enchant Color", with the support of making the enchant glint any color
- Added scaling options to players, items, and tamed under Nametags ([#1051](https://github.com/ImpactDevelopment/ImpactClient/issues/1051))
- Moved Lag Meter from its own module to a suboption under HUD ([#1065](https://github.com/ImpactDevelopment/ImpactClient/issues/1065))
- Decreased minimum Respawn delay from 2500ms to 250ms
- Decreased minimum AntiAFK swing speed from 1 to 0.01 ([#1157](https://github.com/ImpactDevelopment/ImpactClient/issues/1157))
- Increased maximum speed for Elytra+ Control mode from 6 to 30 ([#1325](https://github.com/ImpactDevelopment/ImpactClient/issues/1325))
- Color picker now saves rainbow status between sessions ([#766](https://github.com/ImpactDevelopment/ImpactClient/issues/766))

### Fixed
- Fixed ESP Shader mode not rendering Phantoms with the right color, caused by their eye layer
- Fixed thread unsafe operation in Chest Stealer that could result in a game crash
- Fixed URL links not working in 1.13.2+ ([#1151](https://github.com/ImpactDevelopment/ImpactClient/issues/1151))
- Fixed Lag Meter rendering in singleplayer ([#1065](https://github.com/ImpactDevelopment/ImpactClient/issues/1065))
- Fixed Alt manager hanging when Randomizing 0 alts ([#1225](https://github.com/ImpactDevelopment/ImpactClient/issues/1225))
- Fixed spelling of the word "Assassins"
- Fixed Velocity partially inverting knockback by default ([#1168](https://github.com/ImpactDevelopment/ImpactClient/issues/1168))
- Fixed `.locate` for everything except Stronghold and Nether Fortress on 1.12.2 only, still broken on 1.13.2
- Fixed item collation under Inventory ([#1236](https://github.com/ImpactDevelopment/ImpactClient/issues/1236))
- Fixed ClickGUI instantly re-opening itself when toggled off ingame ([#1258](https://github.com/ImpactDevelopment/ImpactClient/issues/1258))
- Fixed blurring of ClickGUI background while scaling ([#1272](https://github.com/ImpactDevelopment/ImpactClient/issues/1272))
- Fixed Nametag and Tracer rare jitter ([#1257](https://github.com/ImpactDevelopment/ImpactClient/issues/1257))
- Fixed Light being totally broken ([#1220](https://github.com/ImpactDevelopment/ImpactClient/issues/1220))
- Fixed typo in Player selector alt text
- Fixed inverted check in Auto Armor ([#1283](https://github.com/ImpactDevelopment/ImpactClient/issues/1283))
- Fixed crash caused by server sending faulty data ([#1241](https://github.com/ImpactDevelopment/ImpactClient/issues/1241))
- Fixed crash when Step mode switched outside of world ([#1102](https://github.com/ImpactDevelopment/ImpactClient/issues/1102))
- Fixed FastLadder under Terrain not working on 1.13.2 ([#1313](https://github.com/ImpactDevelopment/ImpactClient/issues/1313))
- Fixed Jesus interfering with Freecam player movement on 1.12.2 ([#1291](https://github.com/ImpactDevelopment/ImpactClient/issues/1291))
- Fixed AntiAFK and AutoWalk interference with Freecam player movement ([#679](https://github.com/ImpactDevelopment/ImpactClient/issues/679))
- Fixed Murder (Hypixel) not detecting the murderer if they are using a cookie weapon ([#861](https://github.com/ImpactDevelopment/ImpactClient/issues/861))
- Fixed Anti Hunger taking accumulated fall damage when walking into water
- Fixed some broken checks in Crystal Aura
- Fixed freecam causing unexpected behavior with debug chunk borders ([#1128](https://github.com/ImpactDevelopment/ImpactClient/issues/1128))
- Fixed potential issues with Auto Disconnect acting if the local player is dead ([#1349](https://github.com/ImpactDevelopment/ImpactClient/issues/1349))
- Fixed inconsistent functionality of Jesus when riding an animal on water ([#1233](https://github.com/ImpactDevelopment/ImpactClient/issues/1233))
- Fixed AutoEat not working when chat is open ([#1110](https://github.com/ImpactDevelopment/ImpactClient/issues/1110))
- Fixed Terrain's Ladder Speed not working on the 1.13.2 version ([#1313](https://github.com/ImpactDevelopment/ImpactClient/issues/1313))
- Fixed Crystal Aura not properly syncing the held item ([#1140](https://github.com/ImpactDevelopment/ImpactClient/issues/1140))
- Fixed Kill Aura not using Auto Weapon
- Fixed Auto Weapon not firing ([#1314](https://github.com/ImpactDevelopment/ImpactClient/issues/1314))
- Fixed Freecam not respecting the real player's stats (health, armor, etc.) ([#1290](https://github.com/ImpactDevelopment/ImpactClient/issues/1290))
- Fixed rare crash with Storage ESP when server sends faulty data ([#1380](https://github.com/ImpactDevelopment/ImpactClient/issues/1380))
- Fixed poor filter order resulting in Kill Aura Ray Tracing causing FPS drops ([#903](https://github.com/ImpactDevelopment/ImpactClient/issues/903))
- Fixed timer speed not being taken into account with player speed on HUD
- Fixed Auto Eject crash when picking up a throwaway item and in another inventory ([#1371](https://github.com/ImpactDevelopment/ImpactClient/issues/1371))

## 4.6

### Added
- Added suffix to Weather that indicates **Thunder**, **Rain** or **Clear**
- Added options to Trajectories to end on an entity, and to draw a correct centered tracer
- Added Tracers option to Search (i.e. portal tracers)
- Added option to include dropped items in Nametags
- Added TTF option to Nametags
- Added Collate option under Nametags Item Option
  - Will join together item tags so that they become readable
- Added an option "Ignore Dungeons" to StorageESP to not render chests near Mob Spawners ([#995](https://github.com/ImpactDevelopment/ImpactClient/issues/995))
- Added a persistence option to Auto Walk ([#1001](https://github.com/ImpactDevelopment/ImpactClient/issues/1001))
- Added "toggle" and "random" modes for Skin Blinker
- Added option for every model part in Skin Blinker
- Added Tridents to Trajectories
- Added line width option to Trajectories
- Added option to Anti Overlay to hide boss health bars
- Added optional rendering of the target to Crystal Aura (highlighting both to place and to set off) ([#987](https://github.com/ImpactDevelopment/ImpactClient/issues/987))
- Added Lag Meter: notifies you when no packets have been received from the server since a certain amount of time
- Added Durability option to Inventory, to show correct durability in item mouseover tooltip even when damage is negative (e.g. unbreakables) ([#1011](https://github.com/ImpactDevelopment/ImpactClient/issues/1011))
- Added Tamed option to Nametags, to show which player owns tamable mobs ([#909](https://github.com/ImpactDevelopment/ImpactClient/issues/909))
- Added a GUI to manage the Search module
- Added a new Speed mode called On Ground

### Changed
- Made complete entity removal in No Render an option
- Made NCP step ensure the player cannot move while it is waiting ticks to step
- Minor tweaks to the Light brightness fade
- Made "Yaw/Pitch Speed" options in Inventory sub-options of "Look Around"
- Made ClickGUI Scale a slider instead of a checkbox, and made it keep old scale while dragging
- Changed minimum AutoReconnect time delay from 2500ms to 200ms

### Fixed
- Fixed breadcrumbs applying across dimensions
- Fixed breadcrumbs not clearing upon dying
- Fixed sky and rain flickering caused by Weather ("Clear" Mode)
- Fixed Trajectories raytracing when an arrow went out of your line of sight ([#962](https://github.com/ImpactDevelopment/ImpactClient/issues/962))
- Fixed Fast Ladder still working in Terrain even when the module is off
- Fixed strange tick rounding in Trajectories
- Fixed Tracers randomly jumping to the other side of the screen when looking close to 90° away from an entity ([#55](https://github.com/ImpactDevelopment/ImpactClient/issues/55))
- Made font loading on initial startup about 3x faster ([#980](https://github.com/ImpactDevelopment/ImpactClient/issues/980))
- Fixed "NullPointerException" disconnects caused by Log Position
- Fixed Unpack not working with iron blocks and instead recognizing iron ore
- Fixed issue with font renderer where italic and bold characters were not accounted for when calculating string width/height
- Fixed Auto Eat right clicking chests and other containers instead of eating
- Fixed Auto Totem crashing when shift clicking your first totem out of a hopper ([#993](https://github.com/ImpactDevelopment/ImpactClient/issues/993))
- Fixed Skin Blinker not working effectively
- Fixed Flight sending No Kick packets that could cause damage
- Fixed the Allow Place suggestion message triggering at the wrong time ([#1006](https://github.com/ImpactDevelopment/ImpactClient/issues/1006))
- Fixed Crosshair+ drawing on top of the normal crosshair
- Fixed Anti Desync sending completely incorrect packets that get flagged immediately and lag you back
- Fixed Velocity's behavior regarding zeroing velocity vs change in velocity ([#1009](https://github.com/ImpactDevelopment/ImpactClient/issues/1009))
- Fixed some Baritone goals not rendering in Radar
- Fixed Anti Desync breaking in singleplayer ([#1043](https://github.com/ImpactDevelopment/ImpactClient/issues/1043))
- Fixed OptiFine's cape button not being moved out of our way ([#1028](https://github.com/ImpactDevelopment/ImpactClient/issues/1028))
- Fixed time formatting in Log Position regarding month vs minute
- Fixed Speed not respecting Baritone's freeLook direction
- Fixed font height causing extra blank space in ClickGUI tooltips

### Removed
- Removed Screenshot Uploader

### Hotfixes
- Fixed a crash when launching on Linux due to a misconfigured obfuscator
- Fixed a crash due to a 1.13 block rename in Auto Mine
- Fixed entries in ClickGUI showing up in incorrect order due to a misconfigured obfuscator
- Fixed capes rendering at incorrect resolution ([#1060](https://github.com/ImpactDevelopment/ImpactClient/issues/1060))
- Fixed incorrect version displaying in the HUD ([#1069](https://github.com/ImpactDevelopment/ImpactClient/issues/1069))
- Fixed a crash on toggling Impact cape ([#1057](https://github.com/ImpactDevelopment/ImpactClient/issues/1057))
- Fixed mob targeting in 1.13 relating to Phantoms ([#1062](https://github.com/ImpactDevelopment/ImpactClient/issues/1062))
- Fixed a crash relating to potion effects in freecam ([#1058](https://github.com/ImpactDevelopment/ImpactClient/issues/1058))
- Fixed ClickGUI scrolling not working on some systems ([#1061](https://github.com/ImpactDevelopment/ImpactClient/issues/1061))
- Fixed incorrect press vs release logic in Middle Click Friends
- Fixed incorrect rendering of potion effects above modules ([#1064](https://github.com/ImpactDevelopment/ImpactClient/issues/1064))
- Fixed a crash in Search when the shader cannot be created
- Fixed potential crashes related to ResourceLocations ([#1052](https://github.com/ImpactDevelopment/ImpactClient/issues/1052))
- Fixed behavior of Jesus on waterlogged blocks e.g. kelp ([#1063](https://github.com/ImpactDevelopment/ImpactClient/issues/1063))
- Fixed crash when mining redstone ore ([#1121](https://github.com/ImpactDevelopment/ImpactClient/issues/1121))

## 4.5

### Added
- Added a GUI to manage and create [Macros](https://github.com/ImpactDevelopment/ImpactClient/issues/153). A macros system was added in 4.3, but they could only be managed by manually editing the json file.
- Added a color option to Trajectories
- Added error message to Auto Walk "Smart Mode" indicating path calculation failure
- Added a multiplier option to Strafe Speed
- Added Slime option to No Slow
- Added SoulSand option to No Slow
- Added Inventory Open option to Auto Armor
- Added Reverse and Multiplier to horizontal and vertical Velocity options
- Added Chance option to Velocity
- Added Auto Close option to Chest Stealer
- Added Packet Mode to Chest Stealer
  - **Shift**: Shift-clicks items into your inventory
  - **Pickup**: Performs 2 clicks, one to take the item out of the chest, another to put it in your inventory
- Added Placement option for Crystal Aura
- Added GUI that displays if Baritone was not successfully loaded to prevent unexpected behavior
- Added an option to ClickGUI to use Minecraft's GUI scaling
- Adjustable max distance for Tracers
- Separate color for Player entities (Will include others soon)
- Integration with Baritone's processes system for more seamless interaction
- Added Item Frame support to Storage ESP
- Added New Chunks exploit
- Added Suicide option to Crystal Aura
  - **Avoid**: Don't do anything that could kill you
  - **Place**: Place crystals that could kill you
  - **Commit**: Place and hit crystals that could kill you
- Expose all legit mine Baritone options to Auto Mine
- Add Logs to Auto Mine "Bot Mode" default targets
- Added freecam compatibility with everything
  - Thanks leijurv for the scuffed idea of how to do it
  - This means that there should be no conflicts with using Freecam with everything, your "real player" will behave as expected when you're not using Freecam in all circumstances
    - Aka, you can path using Baritone AND use Freecam simultaneously, it's really neat

### Changed
- Changed Ladder Speed in Terrain to have a speed multiplier instead of an obscure speed value
- Changed Category of CrosshairPlus from Misc to Render
- Changed how the Teammate and Friend settings work for ESP and Tracers
  - There are now 3 modes: **Include**, **Restrict**, and **Only**
  - **Include**: Players in this category are included
  - **Restrict**: Players in this category are not included
  - **Only**: Only players in this category are included

### Fixed
- Fixed Minestrike module team check
- Fixed ClickTP sending item interaction packets when teleporting
- Fixed potential `ConcurrentModificationException` in Anti Vanish
- Fixed crash caused by disabling sprint when not in game
- Fixed CrosshairPlus rendering when ``hideGUI`` is true (From pressing F1)
- Fixed Module Mode settings not loading
- Fixed Flight Anti Kick option causing actual teleports to the ground under some circumstances
- Fixed No Slow Item modifier not applying
- Fixed easy way for servers to detect No Rotate
- Sync Preserve Y in Smart Auto Walk with simplifyUnloadedYCoord
- Fixed random quote in Baritone first-time message
- Fixed decimal value instead of integer for the node count in Breadcrumbs
- Fixed the unhelpful usage provided by ``.help baritone``
- Fixed bug that caused some forms of block breaking to be detectable by servers
- Fixed capes still showing after Self Destruct has been activated
- Fixed colossal amount of ``CallbackInfo`` objects being instantiated which could have a considerable memory and performance impact
  - Thank you leijurv for pushing me to actually fix this
- Fixed inconsistent behavior of Anti Hazard's magma option depending on cardinal direction
- Fixed poor animation smoothing for the module list

### Hotfixes
- Fixed not showing Nametags or Tracers for the player while in Freecam ([#944](https://github.com/ImpactDevelopment/ImpactClient/issues/944))
- Fixed Freecam no longer sharing the player's inventory (4.5 regression) ([#946](https://github.com/ImpactDevelopment/ImpactClient/issues/946))
- Fixed Freecam being affected by F5 mode ([#947](https://github.com/ImpactDevelopment/ImpactClient/issues/947))
- Fixed New Chunks ignoring their dimension ([#950](https://github.com/ImpactDevelopment/ImpactClient/issues/950))
- Fixed `.goto` not working as expected ([#948](https://github.com/ImpactDevelopment/ImpactClient/issues/948))
- Freecam will now disable when the real player dies ([#940](https://github.com/ImpactDevelopment/ImpactClient/issues/940))
- Fixed bad team check applying to all combat modules ([#945](https://github.com/ImpactDevelopment/ImpactClient/issues/945))
- Fixed having to run some Baritone commands twice ([#943](https://github.com/ImpactDevelopment/ImpactClient/issues/943))
- Fixed Auto Walk having a higher priority than Baritone processes
- Added Hunt
- Fixed background of Main Menu ([#846](https://github.com/ImpactDevelopment/ImpactClient/issues/846))
- Fixed Font resolution ([#906](https://github.com/ImpactDevelopment/ImpactClient/issues/906))
- Fixed Damn Daniel ([#842](https://github.com/ImpactDevelopment/ImpactClient/issues/842))
- Added a way to secretly close an inventory without telling the server. Inventory -> Secret Close ([#913](https://github.com/ImpactDevelopment/ImpactClient/issues/913))
- Fixed Freecam not being responsive to real player health, hunger, potions, etc. ([#959](https://github.com/ImpactDevelopment/ImpactClient/issues/959))
- Fixed inverted immune check in Kill Aura
- Fixed flowing water check in Jesus
- Fixed a check in Crystal Aura that was off by 1 heart
- Fixed a crash in the Macros GUI when typing without a textbox focused
- Fixed Freecam being unable to break / place blocks ([#938](https://github.com/ImpactDevelopment/ImpactClient/issues/938))
- Fixed Anti Hazard not avoiding cactus, fire, and pressure plates ([#961](https://github.com/ImpactDevelopment/ImpactClient/issues/961))

## 4.4

### Added
- Tower option for Scaffold
- Lethal option for No Fall Bucket mode to only place water when the fall is lethal
- Debug option for Scaffold to allow for better visualization of block placement
- Delay option for Auto Clicker to use 1.9 attack cooldown
  - Also added TPS Sync sub-option to sync swing delay with TPS
- Discord RPC support
- No SRP module, prevents servers from forcing resource packs
- Added name case change exploit as a command (.rename)
- Added ESP color types (Custom, Team, Health)
- Allow Auto Totem to access crafting slots to retrieve Totems
  - Should be combined with Inventory's "Extra Slots" feature
- Added Fancy Chat module to type in alternative latin charsets
- Added command to check fall damage to a block (.falldamage)
  - Checks the fall damage to the block you are looking at
- Added Ping Spoof module
- Added Integration with Baritone
  - Add Auto Mine Bot Mode
  - Add Auto Walk Smart Mode
  - Add Baritone configuration in GUI
  - Made Radar show current calculating and executing path
  - and more!
- Added Bot option to Auto Mine (Automatically mine to ores)
- Added Lava and Portals to Xray by default
- Added Durability option to Item Saver. Ranges from 0-50% where 0% represents 0 durability.
- Added Immune option to Kill Aura. If on, will only attack entities that aren't immune to damage.
- Added Web mode to NoFall, functions the same as Bucket except is able to place webs.
- Added visible ticks option to Minestrike
- Added prioritization modes to Minestrike (Currently world distance and crosshair distance)
- Added aim type to Minestrike, allowing the user to choose when the aimbot should lock on
  - Options are Always and (when) Shooting
- Added "Dolphin" fallback to Jesus Solid mode when flowing is off
- Added a built in color picker to the Click Gui
- Added Block ESP/Search along with a .search command
- Added Extended Tooltips option to Click GUI
  - Will show the name of the component as well as it's description when hovered
- Added ToggleTab
  - Can be enabled/disabled with `.gui toggletab <enable/disable>`
- Added Time widget to HUD
- Added Item Use option to Auto Clicker
  - Toggle the ability to use items and have Auto Clicker work simultaneously
- Added Portal God Mode exploit
- Path option in Radar to make Baritone's current path optional
- Stipple option in Radar to enable/disable path line stippling

### Changed
- Separated horizontal and vertical speed in Freecam
- Changed Fast Interact's Fast Break option from breaking blocks faster to lowering block break delay
- Made latency compensation in the Minestrike module optional
- Xray and Nuker config files will now use namespace block ids instead of numerical
- Moved TPS Sync option to Kill Aura from Delay Mode (The Immune option uses it)
- Made Auto Shoot an option in Minestrike (Was previously on by default)
- Utilize the new Color Picker on all modules with customizable colors
- Keybinds are now saved as strings, improving future compatibility
- Made horizontal and vertical velocity options affect explosions in Velocity module
- Renamed Portal GUI to Portals
  - Added God Mode exploit

### Removed
- Removed Item Physics

### Fixed
- Fixed uncommon crash caused by GuiTextContainingLinks
- Fixed Scaffold not working on NCP due to bad angles
- Fixed Scaffold providing server with suspicious looking packets
- Fixed Scaffold crashing under specific conditions
- Fixed Riding causing boats to bob if the swim option is checked
- Step working when in water or lava
- Fixed enum type values not saving/loading properly
  - Only affected options for HUD module
- Fixed bug with Auto Tool that caused game to crash under specific circumstances
  - Crashed when there was not a valid tool on the hotbar and it has not previously succeeded
- Fixed boat rotation in the Riding module
  - Boats now rotate to the direction that you're looking
  - Fixed "strafing" while in boats
- Fixed Anti Vanish causing the game to crash
- Fixed Flowing option for Jesus Solid mode
- Fixed ColorType values loading with 0 opacity
- Fixed Criticals not working while sprinting
- Fixed issues caused by Fast Render by forcefully disabling it
- Fixed hopper and furnace minecarts not being shown by Storage ESP
- Fixed the ability to execute other commands during spam setup
- Fixed not being able to place end crystals at sky limit (Vanilla bug)
- Fixed Anti Hazard not working on fire
- Fixed rare occurance of server receiving angles that were out of bounds
- Fixed Ignite not breaking blocks that are preventing ignition of targets
- Fixed Auto Eat not working while in a GUI screen
- Fixed Freecam causing kicks on some servers, and in general, not functioning as expected
- Fixed Scaffold not being able to place slabs correctly
- Fixed Scaffold not being able to place blocks off of glass
- Fixed Scaffold not being able to place in positions that are replaceable
- Minor improvements to Crosshair+
- Fixed issue with Self Destruct that did not restore GUIs fully
- Fixed No Slow water option preventing moving up
- Fixed Perspective not having an expected angle change
- Fixed incomplete description of Fire option for Anti Hazard
- Fixed movement input being passed through while in chat and Anti AFK is on
- Fixed lighting bug caused by Shader ESP
- Fixed path rendering in radar not respecting Baritone color settings

## 4.3

### Added
- Button to open Click GUI from the Impact menu
- Ability to open chat while Click GUI is open
- "Main Menu" entry in Click GUI's Render section
  - Toggle using Impact's custom main menu
  - Toggle using Impact's replacement menu wallpaper
- Clickable links and line-wrapping in the MOTD header
- Colored sign text exploit
- Movement speed widget in the HUD
- Customization for suffixes in module list
- Pause option for Click GUI
- Opacity option for Click GUI
- Option to blur background of Click GUI frames
- Option to save logout positions in Log Position
- Rank option for Nametags to show team prefix and suffix
- Catch Delay option for AutoFish (might help with fussy servers)
- Jump option for the strafe speed mode
- Skylight option for light module to prevent skylight lag machines from working
- Totem counter option to Auto Totem
- Auto Break option for nuker
- Origin option for nuker to choose the break origin
- Target option for nuker to choose the blocks targetted
- Filter option for nuker to use the nuker ID list
- Crosshair prioritization mode for Kill Aura
- Swing option for Scaffold
- Shulker Tooltip option for Inventory to change the tooltip length
- Shulker Coallate option for Inventory to group item stacks together in the tooltip
- Option to only shoot when scoped for Minestrike module
- Option to ignore attacking friends for Minestrike module
- Support for offhand in Scaffold
  - Added option to prioritize offhand which is on by default
- Swing option for breaker to show breaking on the client side
- "Reconnect" command that quickly disconnects and reconnects the user from their current server

### Changed
- Use player's team color in Nametags
- AutoFish options should be clearer now
- AutoFish AutoCast is now off by default
- Automatically focus the username field when creating an Alt
- Alts are now stored in a json format to enable future fanciness
- Significantly improve scaffold in all movement directions
- Improve jitter on Auto Clicker
- Added mineplex support for team check
- Freecam is now always in first person view
- Moved Inventory to the Misc category, updated its description and made move an option
- Click GUI menus now stay on the screen at all times
- Click GUI menus are now easier to navigate
  - Clicking the arrows next to modules will open the submen
  - Double clicking the menus will open them (like right click)
  - Move menus around by dragging anywhere within them (hold `Ctrl` or use middle mouse)
- Click GUI's keybind widget now has a tooltip and is easier to use
  - Left click to modify the bind
  - Clicking again (or pressing `Esc` will cancel)
  - Right click to delete/reset the bind
- `.set` command can now use option id as an alternative to name
- Removed all server-side changes (should make singleplayer more stable)

### Removed
- Mode option for nuker

### Fixed
- Absorption not being shown by Nametags
- `.set` command not finding nested options
- Fixed incorrect angle calculations in combat modules
- Incorrect murderer detection on Hypixel's Murder Mystery
- Incorrect murderer detection on PlayMCM
- No Fall Bucket mode getting stuck on the collection stage
- Dolphin Jesus jumping while in GUIs, even when out of water
- Xray GUI arrows not displaying with a transparent background
- Not being able to toggle mods or open Click GUI after toggling fullscreen mode
- Click GUI not always being saved on shutdown
- Issues caused when disabling the Click GUI
- Click GUI not rendering closed menus correctly until they are re-closed
- drop command not targetting correct slots
- Chams affecting models in the alt manager
- Smooth aim targetting incorrect positions
- Friends GUI causing a crash
- Alt GUI having transparent background while in-game
- Some vertical spacing problems with the HUD
- Cycler boxes in Click GUI not properly encasing children
- Freecam causing weird behavior while riding entities
- ChestStealer not functioning as expected
- Forge and Optifine support ~~(probably)~~
- AntiAFK "jump" option not working when a GUI is open
- AutoTool not applying to Nuker
- Fixed Riding "Entity Speed" not applying to boats
- Fixed Scaffold not placing glass blocks
